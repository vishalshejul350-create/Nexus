const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Post = require('../models/Post');
const User = require('../models/User');
const auth = require('../middleware/auth');

// @route   GET /api/posts
// @desc    Get all posts (feed)
// @access  Private
router.get('/', auth, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const skip = (page - 1) * limit;

        const posts = await Post.find()
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .populate('author', 'name username')
            .populate({
                path: 'comments',
                populate: { path: 'author', select: 'name username' },
                options: { limit: 3, sort: { createdAt: -1 } }
            });

        const formattedPosts = posts.map(post => ({
            id: post._id,
            author: {
                id: post.author._id,
                name: post.author.name,
                username: post.author.username,
                avatar: post.author.getInitials()
            },
            content: post.content,
            image: post.image,
            likeCount: post.likes.length,
            commentCount: post.comments.length,
            shareCount: post.shares,
            liked: post.likes.includes(req.userId),
            comments: post.comments.map(comment => ({
                id: comment._id,
                author: {
                    name: comment.author.name,
                    username: comment.author.username,
                    avatar: comment.author.getInitials()
                },
                text: comment.text,
                createdAt: comment.createdAt
            })),
            createdAt: post.createdAt
        }));

        res.json({
            success: true,
            posts: formattedPosts,
            page,
            hasMore: posts.length === limit
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'पोस्ट मिळवताना त्रुटी' 
        });
    }
});

// @route   GET /api/posts/following
// @desc    Get posts from followed users
// @access  Private
router.get('/following', auth, async (req, res) => {
    try {
        const currentUser = await User.findById(req.userId);
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const skip = (page - 1) * limit;

        const posts = await Post.find({ 
            author: { $in: currentUser.following } 
        })
            .sort({ createdAt: -1 })
            .skip(skip)
            .limit(limit)
            .populate('author', 'name username')
            .populate({
                path: 'comments',
                populate: { path: 'author', select: 'name username' },
                options: { limit: 3, sort: { createdAt: -1 } }
            });

        const formattedPosts = posts.map(post => ({
            id: post._id,
            author: {
                id: post.author._id,
                name: post.author.name,
                username: post.author.username,
                avatar: post.author.getInitials()
            },
            content: post.content,
            image: post.image,
            likeCount: post.likes.length,
            commentCount: post.comments.length,
            shareCount: post.shares,
            liked: post.likes.includes(req.userId),
            comments: post.comments.map(comment => ({
                id: comment._id,
                author: {
                    name: comment.author.name,
                    username: comment.author.username,
                    avatar: comment.author.getInitials()
                },
                text: comment.text,
                createdAt: comment.createdAt
            })),
            createdAt: post.createdAt
        }));

        res.json({
            success: true,
            posts: formattedPosts,
            page,
            hasMore: posts.length === limit
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'पोस्ट मिळवताना त्रुटी' 
        });
    }
});

// @route   POST /api/posts
// @desc    Create a new post
// @access  Private
router.post('/', [
    auth,
    body('content').trim().notEmpty().withMessage('पोस्ट कंटेंट आवश्यक आहे')
        .isLength({ max: 1000 }).withMessage('पोस्ट १००० अक्षरांपेक्षा लहान असावी')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ 
                success: false, 
                errors: errors.array() 
            });
        }

        const { content, image } = req.body;

        const post = new Post({
            author: req.userId,
            content,
            image: image || ''
        });

        await post.save();
        await post.populate('author', 'name username');

        res.status(201).json({
            success: true,
            message: 'पोस्ट तयार झाली!',
            post: {
                id: post._id,
                author: {
                    id: post.author._id,
                    name: post.author.name,
                    username: post.author.username,
                    avatar: post.author.getInitials()
                },
                content: post.content,
                image: post.image,
                likeCount: 0,
                commentCount: 0,
                shareCount: 0,
                liked: false,
                comments: [],
                createdAt: post.createdAt
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'पोस्ट तयार करताना त्रुटी' 
        });
    }
});

// @route   DELETE /api/posts/:id
// @desc    Delete a post
// @access  Private
router.delete('/:id', auth, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ 
                success: false, 
                message: 'पोस्ट सापडली नाही' 
            });
        }

        if (post.author.toString() !== req.userId.toString()) {
            return res.status(403).json({ 
                success: false, 
                message: 'तुम्हाला ही पोस्ट डिलीट करण्याचा अधिकार नाही' 
            });
        }

        await post.deleteOne();

        res.json({
            success: true,
            message: 'पोस्ट डिलीट झाली!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'पोस्ट डिलीट करताना त्रुटी' 
        });
    }
});

// @route   POST /api/posts/:id/like
// @desc    Like a post
// @access  Private
router.post('/:id/like', auth, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ 
                success: false, 
                message: 'पोस्ट सापडली नाही' 
            });
        }

        if (post.likes.includes(req.userId)) {
            return res.status(400).json({ 
                success: false, 
                message: 'तुम्ही आधीच लाईक केली आहे' 
            });
        }

        post.likes.push(req.userId);
        await post.save();

        res.json({
            success: true,
            message: 'लाईक यशस्वी!',
            likeCount: post.likes.length
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'लाईक करताना त्रुटी' 
        });
    }
});

// @route   DELETE /api/posts/:id/like
// @desc    Unlike a post
// @access  Private
router.delete('/:id/like', auth, async (req, res) => {
    try {
        const post = await Post.findById(req.params.id);

        if (!post) {
            return res.status(404).json({ 
                success: false, 
                message: 'पोस्ट सापडली नाही' 
            });
        }

        post.likes = post.likes.filter(
            id => id.toString() !== req.userId.toString()
        );
        await post.save();

        res.json({
            success: true,
            message: 'अनलाईक यशस्वी!',
            likeCount: post.likes.length
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'अनलाईक करताना त्रुटी' 
        });
    }
});

module.exports = router;
