const express = require('express');
const router = express.Router();
const User = require('../models/User');
const auth = require('../middleware/auth');

// @route   GET /api/users/search
// @desc    Search users
// @access  Private
router.get('/search', auth, async (req, res) => {
    try {
        const { q } = req.query;

        if (!q) {
            return res.status(400).json({ 
                success: false, 
                message: 'सर्च क्वेरी आवश्यक आहे' 
            });
        }

        const users = await User.find({
            $or: [
                { name: { $regex: q, $options: 'i' } },
                { username: { $regex: q, $options: 'i' } }
            ],
            _id: { $ne: req.userId }
        })
        .select('name username bio')
        .limit(20);

        res.json({
            success: true,
            users: users.map(user => ({
                id: user._id,
                name: user.name,
                username: user.username,
                bio: user.bio,
                avatar: user.getInitials()
            }))
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'सर्च करताना त्रुटी' 
        });
    }
});

// @route   GET /api/users/suggestions
// @desc    Get suggested users to follow
// @access  Private
router.get('/suggestions', auth, async (req, res) => {
    try {
        const currentUser = await User.findById(req.userId);

        const suggestions = await User.find({
            _id: { 
                $ne: req.userId,
                $nin: currentUser.following 
            }
        })
        .select('name username bio')
        .limit(5);

        res.json({
            success: true,
            suggestions: suggestions.map(user => ({
                id: user._id,
                name: user.name,
                username: user.username,
                bio: user.bio,
                avatar: user.getInitials()
            }))
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'सूचना मिळवताना त्रुटी' 
        });
    }
});

// @route   GET /api/users/:username
// @desc    Get user profile
// @access  Private
router.get('/:username', auth, async (req, res) => {
    try {
        const user = await User.findOne({ username: req.params.username })
            .select('-password')
            .populate('followers', 'name username')
            .populate('following', 'name username');

        if (!user) {
            return res.status(404).json({ 
                success: false, 
                message: 'युजर सापडला नाही' 
            });
        }

        const isFollowing = user.followers.some(
            follower => follower._id.toString() === req.userId.toString()
        );

        res.json({
            success: true,
            user: {
                id: user._id,
                name: user.name,
                username: user.username,
                bio: user.bio,
                avatar: user.getInitials(),
                followerCount: user.followers.length,
                followingCount: user.following.length,
                isFollowing,
                isOwnProfile: user._id.toString() === req.userId.toString()
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'प्रोफाइल मिळवताना त्रुटी' 
        });
    }
});

// @route   POST /api/users/:id/follow
// @desc    Follow a user
// @access  Private
router.post('/:id/follow', auth, async (req, res) => {
    try {
        const userToFollow = await User.findById(req.params.id);
        const currentUser = await User.findById(req.userId);

        if (!userToFollow) {
            return res.status(404).json({ 
                success: false, 
                message: 'युजर सापडला नाही' 
            });
        }

        if (req.params.id === req.userId.toString()) {
            return res.status(400).json({ 
                success: false, 
                message: 'तुम्ही स्वतःला फॉलो करू शकत नाही' 
            });
        }

        // Check if already following
        if (currentUser.following.includes(req.params.id)) {
            return res.status(400).json({ 
                success: false, 
                message: 'तुम्ही आधीच फॉलो करत आहात' 
            });
        }

        // Add to following and followers
        currentUser.following.push(req.params.id);
        userToFollow.followers.push(req.userId);

        await currentUser.save();
        await userToFollow.save();

        res.json({
            success: true,
            message: 'फॉलो यशस्वी!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'फॉलो करताना त्रुटी' 
        });
    }
});

// @route   DELETE /api/users/:id/follow
// @desc    Unfollow a user
// @access  Private
router.delete('/:id/follow', auth, async (req, res) => {
    try {
        const userToUnfollow = await User.findById(req.params.id);
        const currentUser = await User.findById(req.userId);

        if (!userToUnfollow) {
            return res.status(404).json({ 
                success: false, 
                message: 'युजर सापडला नाही' 
            });
        }

        // Remove from following and followers
        currentUser.following = currentUser.following.filter(
            id => id.toString() !== req.params.id
        );
        userToUnfollow.followers = userToUnfollow.followers.filter(
            id => id.toString() !== req.userId.toString()
        );

        await currentUser.save();
        await userToUnfollow.save();

        res.json({
            success: true,
            message: 'अनफॉलो यशस्वी!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'अनफॉलो करताना त्रुटी' 
        });
    }
});

module.exports = router;
