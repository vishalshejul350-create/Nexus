const express = require('express');
const router = express.Router();
const { body, validationResult } = require('express-validator');
const Comment = require('../models/Comment');
const Post = require('../models/Post');
const auth = require('../middleware/auth');

// @route   POST /api/comments
// @desc    Create a comment
// @access  Private
router.post('/', [
    auth,
    body('postId').notEmpty().withMessage('पोस्ट ID आवश्यक आहे'),
    body('text').trim().notEmpty().withMessage('कमेंट टेक्स्ट आवश्यक आहे')
        .isLength({ max: 500 }).withMessage('कमेंट ५०० अक्षरांपेक्षा लहान असावा')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ 
                success: false, 
                errors: errors.array() 
            });
        }

        const { postId, text } = req.body;

        const post = await Post.findById(postId);
        if (!post) {
            return res.status(404).json({ 
                success: false, 
                message: 'पोस्ट सापडली नाही' 
            });
        }

        const comment = new Comment({
            author: req.userId,
            post: postId,
            text
        });

        await comment.save();
        await comment.populate('author', 'name username');

        // Add comment to post
        post.comments.push(comment._id);
        await post.save();

        res.status(201).json({
            success: true,
            message: 'कमेंट तयार झाली!',
            comment: {
                id: comment._id,
                author: {
                    name: comment.author.name,
                    username: comment.author.username,
                    avatar: comment.author.getInitials()
                },
                text: comment.text,
                createdAt: comment.createdAt
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'कमेंट तयार करताना त्रुटी' 
        });
    }
});

// @route   DELETE /api/comments/:id
// @desc    Delete a comment
// @access  Private
router.delete('/:id', auth, async (req, res) => {
    try {
        const comment = await Comment.findById(req.params.id);

        if (!comment) {
            return res.status(404).json({ 
                success: false, 
                message: 'कमेंट सापडली नाही' 
            });
        }

        if (comment.author.toString() !== req.userId.toString()) {
            return res.status(403).json({ 
                success: false, 
                message: 'तुम्हाला ही कमेंट डिलीट करण्याचा अधिकार नाही' 
            });
        }

        // Remove comment from post
        await Post.findByIdAndUpdate(comment.post, {
            $pull: { comments: comment._id }
        });

        await comment.deleteOne();

        res.json({
            success: true,
            message: 'कमेंट डिलीट झाली!'
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'कमेंट डिलीट करताना त्रुटी' 
        });
    }
});

module.exports = router;
