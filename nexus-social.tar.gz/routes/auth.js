const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const auth = require('../middleware/auth');

// Generate JWT token
const generateToken = (userId) => {
    return jwt.sign({ userId }, process.env.JWT_SECRET || 'default-secret-key', {
        expiresIn: '30d'
    });
};

// @route   POST /api/auth/signup
// @desc    Register a new user
// @access  Public
router.post('/signup', [
    body('name').trim().notEmpty().withMessage('नाव आवश्यक आहे'),
    body('email').isEmail().withMessage('वैध ईमेल टाका'),
    body('username').trim().isLength({ min: 3 }).withMessage('युजरनेम किमान ३ अक्षरांचे असावे'),
    body('password').isLength({ min: 6 }).withMessage('पासवर्ड किमान ६ अक्षरांचा असावा')
], async (req, res) => {
    try {
        // Validation
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ 
                success: false, 
                errors: errors.array() 
            });
        }

        const { name, email, username, password } = req.body;

        // Check if user exists
        const existingUser = await User.findOne({ 
            $or: [{ email }, { username }] 
        });

        if (existingUser) {
            return res.status(400).json({ 
                success: false, 
                message: 'हा ईमेल किंवा युजरनेम आधीच वापरला आहे' 
            });
        }

        // Create user
        const user = new User({
            name,
            email,
            username,
            password
        });

        await user.save();

        // Generate token
        const token = generateToken(user._id);

        res.status(201).json({
            success: true,
            message: 'साइनअप यशस्वी!',
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                username: user.username,
                avatar: user.getInitials()
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'साइनअप करताना त्रुटी' 
        });
    }
});

// @route   POST /api/auth/login
// @desc    Login user
// @access  Public
router.post('/login', [
    body('email').isEmail().withMessage('वैध ईमेल टाका'),
    body('password').notEmpty().withMessage('पासवर्ड आवश्यक आहे')
], async (req, res) => {
    try {
        // Validation
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ 
                success: false, 
                errors: errors.array() 
            });
        }

        const { email, password } = req.body;

        // Find user with password
        const user = await User.findOne({ email }).select('+password');

        if (!user) {
            return res.status(401).json({ 
                success: false, 
                message: 'चुकीचा ईमेल किंवा पासवर्ड' 
            });
        }

        // Check password
        const isMatch = await user.comparePassword(password);

        if (!isMatch) {
            return res.status(401).json({ 
                success: false, 
                message: 'चुकीचा ईमेल किंवा पासवर्ड' 
            });
        }

        // Generate token
        const token = generateToken(user._id);

        res.json({
            success: true,
            message: 'लॉगिन यशस्वी!',
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                username: user.username,
                avatar: user.getInitials()
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'लॉगिन करताना त्रुटी' 
        });
    }
});

// @route   GET /api/auth/me
// @desc    Get current user
// @access  Private
router.get('/me', auth, async (req, res) => {
    try {
        const user = await User.findById(req.userId)
            .select('-password')
            .populate('followers', 'name username')
            .populate('following', 'name username');

        res.json({
            success: true,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                username: user.username,
                bio: user.bio,
                avatar: user.getInitials(),
                followers: user.followers,
                following: user.following,
                followerCount: user.followers.length,
                followingCount: user.following.length
            }
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({ 
            success: false, 
            message: 'युजर माहिती मिळवताना त्रुटी' 
        });
    }
});

module.exports = router;
