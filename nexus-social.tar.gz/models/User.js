const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'नाव आवश्यक आहे'],
        trim: true,
        maxlength: 50
    },
    email: {
        type: String,
        required: [true, 'ईमेल आवश्यक आहे'],
        unique: true,
        lowercase: true,
        trim: true,
        match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, 'कृपया वैध ईमेल टाका']
    },
    password: {
        type: String,
        required: [true, 'पासवर्ड आवश्यक आहे'],
        minlength: 6,
        select: false
    },
    username: {
        type: String,
        required: [true, 'युजरनेम आवश्यक आहे'],
        unique: true,
        trim: true,
        lowercase: true,
        maxlength: 30
    },
    bio: {
        type: String,
        maxlength: 200,
        default: ''
    },
    avatar: {
        type: String,
        default: ''
    },
    followers: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    following: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User'
    }],
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Hash password before saving
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(this.password, salt);
        next();
    } catch (error) {
        next(error);
    }
});

// Compare password method
userSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Get user's initials for avatar
userSchema.methods.getInitials = function() {
    return this.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
};

module.exports = mongoose.model('User', userSchema);
