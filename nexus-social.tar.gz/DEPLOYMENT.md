# 🚀 DEPLOYMENT GUIDE - पूर्ण मार्गदर्शक

ही गाईड फॉलो करून तुम्ही तुमची वेबसाइट ऑनलाइन करू शकता.

---

## 🎯 सर्वात सोपा मार्ग: Render.com (100% मोफत)

### स्टेप-बाय-स्टेप गाईड

---

## 📦 PART 1: MongoDB Atlas सेटअप (Database)

### 1.1 Account तयार करा

1. https://www.mongodb.com/cloud/atlas वर जा
2. "Try Free" बटण क्लिक करा
3. तुमच्या ईमेलने साइन अप करा (किंवा Google account वापरा)
4. Account verify करा

### 1.2 Database तयार करा

1. Dashboard वर "Build a Database" क्लिक करा
2. **FREE tier (M0)** निवडा - ही पूर्णपणे मोफत आहे!
3. Cloud Provider निवडा:
   - **AWS** recommended
   - Region: **Mumbai** (N. Virginia पण चालेल)
4. Cluster Name: `nexus-cluster` (कोणतंही नाव देऊ शकता)
5. "Create" बटण क्लिक करा
6. 3-5 मिनिटे थांबा (cluster तयार होत आहे)

### 1.3 Database User तयार करा

1. Left sidebar मध्ये "Database Access" क्लिक करा
2. "Add New Database User" क्लिक करा
3. माहिती भरा:
   - **Username**: `nexusadmin` (काहीही असू शकतं)
   - **Password**: मजबूत password टाका (लक्षात ठेवा!)
   - किंवा "Autogenerate Secure Password" वापरा
4. User Privileges: "Read and write to any database" निवडा
5. "Add User" क्लिक करा

**महत्वाचं**: Username आणि Password कुठे तरी save करून ठेवा!

### 1.4 Network Access परवानगी द्या

1. Left sidebar मध्ये "Network Access" क्लिक करा
2. "Add IP Address" क्लिक करा
3. "Allow Access from Anywhere" निवडा
4. Confirm करा

### 1.5 Connection String मिळवा

1. "Database" tab वर जा
2. तुमच्या cluster च्या समोर "Connect" बटण क्लिक करा
3. "Connect your application" निवडा
4. "Driver" आणि "Version" बघा:
   - Driver: Node.js
   - Version: 4.1 or later
5. Connection string कॉपी करा

String असा दिसेल:
```
mongodb+srv://nexusadmin:<password>@nexus-cluster.xxxxx.mongodb.net/?retryWrites=true&w=majority
```

**महत्वाचं**: 
- `<password>` च्या जागी तुमचा password घाला
- शेवटी `?retryWrites...` च्या आधी `/nexus-social` जोडा

Final string:
```
mongodb+srv://nexusadmin:yourpassword@nexus-cluster.xxxxx.mongodb.net/nexus-social?retryWrites=true&w=majority
```

ही string सुरक्षित ठेवा! आपल्याला लागेल.

---

## 🐙 PART 2: GitHub वर Code Upload करा

### 2.1 GitHub Account तयार करा

1. https://github.com वर जा
2. "Sign up" क्लिक करा
3. Account तयार करा (मोफत आहे)

### 2.2 New Repository तयार करा

1. GitHub वर लॉगिन करा
2. वर उजवीकडे "+" आयकॉन क्लिक करा
3. "New repository" निवडा
4. माहिती भरा:
   - Repository name: `nexus-social`
   - Description: "My social media platform"
   - **Public** निवडा
   - "Add a README file" **चेक करू नका**
5. "Create repository" क्लिक करा

### 2.3 Code Upload करा

**पर्याय A: GitHub Desktop वापरा (सोपं)**

1. https://desktop.github.com/ वरून GitHub Desktop download करा
2. Install करा आणि sign in करा
3. "File" > "Add Local Repository" निवडा
4. तुमचा `nexus-social` folder निवडा
5. "Publish repository" क्लिक करा

**पर्याय B: Git Commands (Terminal/CMD)**

तुमच्या `nexus-social` folder मध्ये terminal उघडा:

```bash
git init
git add .
git commit -m "First commit"
git branch -M main
git remote add origin https://github.com/your-username/nexus-social.git
git push -u origin main
```

`your-username` च्या जागी तुमचं GitHub username घाला.

**पर्याय C: Web Upload (सर्वात सोपं पण वेळ घेणारं)**

1. तुमच्या repository वर जा
2. "Add file" > "Upload files" क्लिक करा
3. सगळ्या files drag & drop करा
4. "Commit changes" क्लिक करा

---

## 🌐 PART 3: Render.com वर Deploy करा

### 3.1 Render Account तयार करा

1. https://render.com वर जा
2. "Get Started for Free" क्लिक करा
3. "Sign up with GitHub" निवडा (recommended)
4. GitHub ने authorize करा

### 3.2 Web Service तयार करा

1. Dashboard वर "New +" बटण क्लिक करा
2. "Web Service" निवडा
3. "Connect a repository" मध्ये तुमची `nexus-social` repository निवडा
4. जर दिसत नसेल तर "Configure account" क्लिक करा आणि access द्या

### 3.3 Service Configure करा

खालील settings भरा:

```
Name: nexus-social
(किंवा कोणतंही unique नाव)

Region: Singapore
(किंवा कोणताही जवळचा region)

Branch: main

Root Directory: (रिकामं ठेवा)

Runtime: Node

Build Command: npm install

Start Command: npm start

Instance Type: Free
```

### 3.4 Environment Variables जोडा

"Environment Variables" section मध्ये हे variables जोडा:

**Variable 1:**
```
Key: MONGODB_URI
Value: [तुमची MongoDB connection string इथे paste करा]
```

**Variable 2:**
```
Key: JWT_SECRET
Value: [कोणतीही लांब random string, उदा: mysuper123secret456key789xyz]
```

**Variable 3:**
```
Key: PORT
Value: 5000
```

**Variable 4:**
```
Key: NODE_ENV
Value: production
```

### 3.5 Deploy करा!

1. "Create Web Service" बटण क्लिक करा
2. Deployment सुरू होईल
3. 5-10 मिनिटे थांबा (पहिल्या वेळी वेळ लागतो)
4. "Live" दिसेल तेव्हा deploy झालं!

### 3.6 तुमची Website URL मिळवा

Deploy झाल्यावर तुम्हाला URL मिळेल:
```
https://nexus-social.onrender.com
```
(किंवा तुम्ही दिलेलं नाव)

**ही URL तुमची website आहे!** इतरांना share करा! 🎉

---

## ✅ चाचणी करा

1. तुमची website URL browser मध्ये उघडा
2. "साइनअप करा" क्लिक करा
3. नवीन account तयार करा
4. पोस्ट करून बघा!

---

## 🔄 Code Update कसा करायचा?

जेव्हा तुम्ही code बदलाल:

1. GitHub वर नवीन code push करा
2. Render automatically नवीन version deploy करेल
3. 2-3 मिनिटे थांबा
4. Changes live होतील!

---

## 🎨 Custom Domain जोडायचा असल्यास (पर्यायी)

### Free Subdomain (Render Provided)
तुम्हाला आधीच मिळाला: `yourapp.onrender.com`

### Custom Domain खरेदी करा
1. **Domain खरेदी करा**:
   - GoDaddy, Namecheap, Hostinger वगैरे
   - Cost: ₹200-500/year

2. **Render मध्ये जोडा**:
   - Render dashboard > Settings > Custom Domains
   - तुमचं domain add करा
   - DNS records update करा (instructions मिळतील)

---

## 💰 खर्च

- **MongoDB Atlas**: मोफत (M0 tier - 512MB storage)
- **Render.com**: मोफत (750 hours/month)
- **GitHub**: मोफत
- **Total**: **₹0** 🎉

---

## ⚠️ Free Plan Limitations

### Render Free Tier:
- Sleep after 15 minutes inactivity
- First request नंतर wake up (30 seconds लागतात)
- 750 hours/month (पुरेसे आहे!)

### Upgrade करायचं असल्यास:
- Render: $7/month (24/7 awake)
- MongoDB: $9/month (2GB storage)

---

## 🆘 समस्या सुटवणं

### Problem: Build Failed
**Solution**:
- GitHub वर सगळ्या files आहेत का check करा
- `package.json` बरोबर आहे का पहा

### Problem: Application Error
**Solution**:
- Environment Variables बरोबर set केले आहेत का?
- MongoDB connection string बरोबर आहे का?
- Render logs check करा

### Problem: Website खूप slow आहे
**Solution**:
- Free tier वापरत असाल तर first request slow असेल
- Paid plan घ्या ($7/month)

### Problem: MongoDB connection error
**Solution**:
- Network Access "Allow from Anywhere" set केलं आहे का?
- Connection string मध्ये password बरोबर आहे का?
- `/nexus-social` database name जोडलं आहे का?

---

## 📱 Mobile App बनवायचं असल्यास

तुमच्या website साठी mobile app बनवायचा असेल तर:

1. **PWA** (Progressive Web App) - आधीच enabled आहे!
   - Mobile browser मध्ये "Add to Home Screen"
   
2. **React Native** - Native app साठी
   - Backend ready आहे, फक्त frontend बदलावा लागेल

3. **Capacitor/Cordova** - HTML ला app मध्ये convert करा

---

## 🎓 पुढे काय करायचं?

1. **Image Upload** जोडा (Cloudinary वापरा)
2. **Real-time Notifications** (Socket.io)
3. **Direct Messages**
4. **Hashtags आणि Search**
5. **Profile Pictures**
6. **Email Notifications**

सगळ्यांसाठी tutorials online available आहेत!

---

## 🎉 शुभेच्छा!

तुम्ही तुमची स्वतःची सोशल मीडिया वेबसाइट बनवली! 🚀

आता तुमचे friends ला invite करा आणि मजा करा!

**Website URL**: तुम्हाला मिळालेली Render URL

प्रश्न असल्यास GitHub Issues वापरा किंवा community forums वर विचारा.

**Happy Coding! 💻✨**
