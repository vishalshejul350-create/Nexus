# Nexus - सोशल मीडिया प्लॅटफॉर्म

पूर्ण Node.js आधारित सोशल मीडिया वेबसाइट जी तुम्ही ऑनलाइन deploy करू शकता.

## 🚀 फीचर्स

- ✅ युजर रजिस्ट्रेशन आणि लॉगिन
- ✅ पोस्ट तयार करा
- ✅ पोस्टला लाईक आणि कमेंट करा
- ✅ इतर युजरला फॉलो/अनफॉलो करा
- ✅ रिअल-टाइम फीड
- ✅ युजर सुचना
- ✅ सिक्युअर JWT ऑथेंटिकेशन
- ✅ मराठी इंटरफेस

## 📋 आवश्यक गोष्टी

- Node.js (version 14 किंवा त्यापेक्षा जास्त)
- MongoDB (लोकल किंवा MongoDB Atlas)
- npm किंवा yarn

## 🛠️ लोकल सेटअप (तुमच्या कॉम्प्युटरवर चालवायचं)

### स्टेप 1: Dependencies Install करा

```bash
npm install
```

### स्टेप 2: Environment Variables सेट करा

`.env.example` ची कॉपी करा आणि `.env` नावाची फाईल बनवा:

```bash
cp .env.example .env
```

`.env` फाईल edit करा:

```env
MONGODB_URI=mongodb://localhost:27017/nexus-social
JWT_SECRET=तुमची-सिक्रेट-की-इथे-घाला
PORT=5000
NODE_ENV=development
```

### स्टेप 3: MongoDB Start करा

तुमच्या सिस्टमवर MongoDB चालू असल्याची खात्री करा.

### स्टेप 4: सर्व्हर Start करा

```bash
npm start
```

आता browser मध्ये उघडा: `http://localhost:5000`

---

## 🌐 ऑनलाइन Deployment (सगळ्यांसाठी accessible)

### पर्याय 1: Render.com वापरून (मोफत, सर्वात सोपं)

#### A) MongoDB Atlas सेटअप

1. **MongoDB Atlas** ला जा: https://www.mongodb.com/cloud/atlas
2. मोफत account तयार करा
3. "Build a Database" क्लिक करा
4. **FREE tier** निवडा (M0 Sandbox)
5. Cloud provider (AWS recommended) आणि region निवडा
6. "Create" क्लिक करा

7. **Database Access Setup**:
   - "Database Access" वर जा
   - "Add New Database User" क्लिक करा
   - Username आणि password टाका (हे लक्षात ठेवा!)
   - "Read and write to any database" परवानगी द्या

8. **Network Access Setup**:
   - "Network Access" वर जा
   - "Add IP Address" क्लिक करा
   - "Allow Access from Anywhere" निवडा (0.0.0.0/0)

9. **Connection String मिळवा**:
   - "Database" वर जा
   - "Connect" बटण क्लिक करा
   - "Connect your application" निवडा
   - Connection string कॉपी करा
   - असं दिसेल: `mongodb+srv://username:<password>@cluster0.xxxxx.mongodb.net/`
   - `<password>` च्या जागी तुमचा password घाला
   - शेवटी `/nexus-social` जोडा

#### B) Render.com वर Deploy करा

1. **GitHub Repository तयार करा**:
   - GitHub वर जा आणि नवीन repository तयार करा
   - तुमचा सगळा कोड upload करा

2. **Render Account तयार करा**:
   - https://render.com वर जा
   - "Get Started for Free" क्लिक करा
   - GitHub ने साइन अप करा

3. **Web Service तयार करा**:
   - Dashboard वर "New +" क्लिक करा
   - "Web Service" निवडा
   - तुमची GitHub repository connect करा

4. **Configuration सेट करा**:
   ```
   Name: nexus-social
   Environment: Node
   Build Command: npm install
   Start Command: npm start
   ```

5. **Environment Variables जोडा**:
   - "Environment" section मध्ये जा
   - हे variables जोडा:
   ```
   MONGODB_URI=तुमची-mongodb-atlas-connection-string
   JWT_SECRET=कोणतीही-लांब-random-string
   PORT=5000
   NODE_ENV=production
   ```

6. **Deploy करा**:
   - "Create Web Service" क्लिक करा
   - 5-10 मिनिटे थांबा
   - तुम्हाला एक URL मिळेल: `https://nexus-social-xxxx.onrender.com`

---

### पर्याय 2: Vercel वापरून (Frontend) + MongoDB Atlas

1. **Vercel Account तयार करा**: https://vercel.com
2. GitHub repository connect करा
3. "Deploy" क्लिक करा
4. Environment Variables जोडा (वरील प्रमाणे)

**नोट**: Vercel serverless functions वापरते, म्हणून तुम्हाला थोडा कोड बदलावा लागेल.

---

### पर्याय 3: Heroku वापरून

1. **Heroku Account**: https://www.heroku.com
2. Heroku CLI install करा
3. Commands:
   ```bash
   heroku login
   heroku create nexus-social-yourname
   heroku config:set MONGODB_URI=your-mongodb-uri
   heroku config:set JWT_SECRET=your-secret
   git push heroku main
   ```

---

## 🔧 महत्वाच्या फाईल्स

- `server.js` - मुख्य सर्व्हर फाईल
- `models/` - Database models
- `routes/` - API routes
- `public/index.html` - Frontend
- `package.json` - Dependencies

## 📱 API Endpoints

### Authentication
- `POST /api/auth/signup` - नवीन युजर तयार करा
- `POST /api/auth/login` - लॉगिन करा
- `GET /api/auth/me` - Current युजर माहिती

### Posts
- `GET /api/posts` - सगळे पोस्ट
- `GET /api/posts/following` - फॉलो केलेल्या लोकांची पोस्ट
- `POST /api/posts` - नवीन पोस्ट
- `POST /api/posts/:id/like` - पोस्ट लाईक करा
- `DELETE /api/posts/:id/like` - पोस्ट अनलाईक करा

### Users
- `GET /api/users/suggestions` - युजर सुचना
- `POST /api/users/:id/follow` - फॉलो करा
- `DELETE /api/users/:id/follow` - अनफॉलो करा

### Comments
- `POST /api/comments` - कमेंट जोडा

## 🎨 Customization

### रंग बदलायचे असल्यास:
`public/index.html` मध्ये CSS मधला gradient बदला:
```css
background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
```

### Logo बदलायचं असल्यास:
HTML मध्ये "Nexus" शोधा आणि तुमचं नाव घाला.

## 🔒 Security Tips

1. `.env` फाईल कधीही GitHub वर upload करू नका
2. JWT_SECRET एक मजबूत random string वापरा
3. Production मध्ये HTTPS वापरा
4. Regular updates ठेवा

## 🆘 समस्या आल्यास

### सर्व्हर start होत नाही:
- MongoDB चालू आहे का ते check करा
- `.env` फाईल बरोबर आहे का ते पहा
- Port आधीच वापरात आहे का ते check करा

### Database connect होत नाही:
- MongoDB URI बरोबर आहे का?
- Network access allow केली आहे का?
- Username/password बरोबर आहे का?

### Deploy नंतर काम करत नाही:
- Environment variables बरोबर सेट केले आहेत का?
- Build logs check करा
- Browser console मध्ये errors पहा

## 📞 संपर्क

प्रश्न असल्यास तुम्ही GitHub Issues वापरू शकता.

## 📄 License

MIT License - तुम्ही हा प्रोजेक्ट मोकळ्या मनाने वापरू शकता आणि modify करू शकता!

---

## 🎉 आनंद घ्या!

तुमची स्वतःची सोशल मीडिया वेबसाइट तयार केल्याबद्दल अभिनंदन! 🚀
